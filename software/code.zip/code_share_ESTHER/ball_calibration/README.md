# ball_calibration Package
Used to find cameras position in world and command jetsons

Refer to [Vision_Guide](../Vision_Guide.md) for information on how to perform calibration 