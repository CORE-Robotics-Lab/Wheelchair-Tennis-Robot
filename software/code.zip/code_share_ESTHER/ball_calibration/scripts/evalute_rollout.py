#!/usr/bin/env python3
"""
Summary: Used to evaluate how good the prediction of the EKF compares to 
the ball position hisotry
Author: Daniel Martin
"""
from cProfile import label
from matplotlib import axes
import rosbag
import rospy
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.widgets import Slider
import matplotlib.lines as mlines
import rospkg


import warnings
warnings.simplefilter('ignore', np.RankWarning)

class EvalTrajectory:
    def __init__(self, path):
        self.MAX_TRAJ_TIME = 3
        self.BOUNCE_START_HEIGHT = 0.3
        self.BOUNCE_COMMIT_HEIGHT = 0.1

        self.selected_trajectory = 0
        self.selected_axis = 2
        self.selected_rollout = 0

        # Read bag
        self.read_bag(path)
        self.process_path()


    def read_bag(self, path):
        bag = rosbag.Bag(path)

        start_times = []
        measurements = []   # [[x, y, z, time], ...]
        predictions = []    # [[x, y, z, vx, vy, vz, time], ...]
        rollouts = []       # [[[x, y, z, time], ...,], ...]

        for topic, msg, t in bag.read_messages():
            # Find start and end time
            if topic == "/ball/event":
                if msg.data == "Launch" or msg.data == "Hit":
                    start_times.append(t.to_sec())

            if topic == "/ball/set_pose":
                start_times.append(t.to_sec())

            if start_times:
                if "_transformed" in topic:
                    p = msg.pose.position
                    camera_id = float(topic[6]) / 6
                    measurements.append([p.x, p.y, p.z, camera_id, msg.header.stamp.to_sec()])
                elif topic == "/ball_odometry":
                    p = msg.pose.pose.position
                    v = msg.twist.twist.linear
                    predictions.append([p.x, p.y, p.z, v.x, v.y, v.z, msg.header.stamp.to_sec()])
                elif topic == "/ball/rollout/path":
                    rollout = []
                    for pose_msg in msg.poses:
                        p = pose_msg.pose.position
                        stamp = pose_msg.header.stamp
                        rollout.append([p.x, p.y, p.z, stamp.to_sec()])
                    rollouts.append(rollout)
        
        self.start_times = start_times
        predictions = sorted(predictions, key=lambda p: p[-1])
        rollouts = sorted(rollouts, key=lambda p: p[0][-1])
        self.orig_measurements, self.orig_predictions, self.orig_rollouts = \
            np.array(measurements), np.array(predictions), np.array(rollouts)

        bag.close()


    # Trim path
    def align_path(self, path, start_t, end_t, numpy=True, rollout=False):
        # Align 3D rollout
        if rollout:
            rollouts = path
            new_rollouts = []
            for rollout in rollouts:
                new_rollout = self.align_path(rollout, start_t, end_t, numpy=True)
                if len(new_rollout) > 0:
                    new_rollouts.append(new_rollout)
            return new_rollouts

        # Align 2D path
        trim_path = []
        for point in path:
            *data, t = point
            if start_t <= t < (start_t + end_t):
                trim_path.append([*data, t - start_t])
        return np.array(trim_path) if numpy else trim_path


    def get_bounce_times(self, path):
        bounce_times = []
        state = "up"
        min_z = np.inf
        min_time = None

        for point in path:
            x, y, z, id, t = point

            if state == "up" and z < self.BOUNCE_START_HEIGHT:
                state = "bouncing"

            if state == "bouncing" and z > self.BOUNCE_COMMIT_HEIGHT:
                state = "up"
                if min_z < .1:
                    bounce_times.append(min_time)
                min_z = np.inf

            if state == "bouncing":
                if z < min_z:
                    min_z = z
                    min_time = t

        return bounce_times


    def isolate_ballistic(self, start_t, end_t, path):
        start_idx, stop_idx = 0, len(path)
        for i, t in enumerate(path[:, -1]):
            if t <= start_t:
                start_idx = i
            if t >= end_t:
                stop_idx = i
                break
        return path[start_idx:stop_idx]


    def fit_trajectory(self, measurements, bounce_times):
        fits = None
        for i in range(len(bounce_times)+1):
            if i == 0:
                s, e = 0, bounce_times[0]
            elif i == len(bounce_times):
                s, e = bounce_times[i-1], np.inf
            else:
                s, e = bounce_times[i-1], bounce_times[i]

            trim_measurements = self.isolate_ballistic(s, e, measurements)
            time = trim_measurements[:, -1]

            if len(trim_measurements) == 0:
                continue

            fit = np.zeros((len(time), 7))
            for axis in range(3):
                samples = trim_measurements[:, axis]

                poly = np.poly1d(np.polyfit(time, samples, 2))
                poly_deriv = np.polyder(poly)

                fit[:, axis] = np.array([poly(t) for t in time])
                fit[:, axis+3] = np.array([poly_deriv(t) for t in time])
            fit[:, -1] = time

            fits = np.vstack((fits, fit)) if (fits is not None) else fit
        return fits


    def find_nearest(self, array, value):
        idx = (np.abs(array - value)).argmin()
        return idx, array[idx]


    def create_trajectory(self, selected_traj):
        start_time = self.start_times[selected_traj]
        next_start = self.start_times[selected_traj +1] if selected_traj != len(self.start_times)-1 else np.inf
        end_time = min(self.MAX_TRAJ_TIME, next_start - start_time)

        # Shift and trim
        self.measurements = self.align_path(self.orig_measurements, start_time, end_time)
        self.predictions = self.align_path(self.orig_predictions, start_time, end_time)
        self.rollouts = self.align_path(self.orig_rollouts, start_time, end_time, rollout=True)

        # if self.predictions.size == 0:
        if self.predictions.size < 20:
            self.selected_trajectory += 1
            self.create_trajectory(self.selected_trajectory)
            return

        self.bounce_times = self.get_bounce_times(self.measurements)
        # self.fits = self.predictions 
        self.fits = self.fit_trajectory(self.measurements, self.bounce_times) # Sometimes errors out


    def process_path(self):
        self.create_trajectory(self.selected_trajectory)

        # Plot
        fig, ax = plt.subplots()

        self.scatter = ax.scatter(self.measurements[:, -1], self.measurements[:, self.selected_axis], s=50, c=self.measurements[:, 3], cmap="cool")
        fit_plot,  = ax.plot(self.fits[:, -1], self.fits[:, self.selected_axis],  'g-', label="Fit")
        pred_plot, = ax.plot(self.predictions[:, -1], self.predictions[:, self.selected_axis], 'b-', label="Predict")
        roll_plot, = ax.plot(self.rollouts[self.selected_rollout][:, -1],
                             self.rollouts[self.selected_rollout][:, self.selected_axis],  'r--', label="Rollout")
        ax.set_ylabel('Axis')
        ax.set_xlabel('Time')
        leg = ax.legend()

        # Slider
        plt.subplots_adjust(bottom=0.3)
        sax = plt.axes([0.20, 0.15, 0.65, 0.03])
        roll_slider = plt.Slider(sax, valmin=0, valmax=1, valinit=self.selected_rollout, label="Rollout %")

        sax = plt.axes([0.20, 0.1, 0.65, 0.03])
        traj_slider = plt.Slider(sax, valmin=0, valmax=len(self.start_times)-1, valinit=self.selected_trajectory, label="Trajectory #", valstep=1)

        sax = plt.axes([0.20, 0.05, 0.65, 0.03])
        axis_slider = plt.Slider(sax, valmin=0, valmax=2, valinit=2, label="X | Y | Z Axis", valstep=1)

        def update_rollout(rollout_per):
            self.selected_rollout = rollout_num = int(rollout_per * (len(self.rollouts)-1))
            roll_plot.set_ydata(self.rollouts[rollout_num][:, self.selected_axis])
            roll_plot.set_xdata(self.rollouts[rollout_num][:, -1])
            fig.canvas.draw()
        roll_slider.on_changed(update_rollout)

        def update_trajectory(selected_traj):
            self.selected_trajectory = selected_traj = int(selected_traj)
            rollout_per = self.selected_rollout/(len(self.rollouts)-1)
            self.create_trajectory(selected_traj)
            update_rollout(rollout_per)
            update_axis(self.selected_axis)
        traj_slider.on_changed(update_trajectory)

        def update_axis(axis):
            self.selected_axis = axis = int(axis)

            self.scatter.remove()
            self.scatter = ax.scatter(self.measurements[:, -1], self.measurements[:, self.selected_axis], s=50, c=self.measurements[:, 3], cmap="cool")

            pred_plot.set_ydata(self.predictions[:, axis])
            pred_plot.set_xdata(self.predictions[:, -1])
            roll_plot.set_ydata(self.rollouts[self.selected_rollout][:, axis])
            roll_plot.set_xdata(self.rollouts[self.selected_rollout][:, -1])
            fit_plot.set_ydata(self.fits[:, axis])
            fit_plot.set_xdata(self.fits[:, -1])

            min_v = min(np.min(self.measurements[:, axis]), np.min(self.predictions[:, axis]))
            max_v  = max(np.max(self.measurements[:, axis]), np.max(self.predictions[:, axis]))
            ax.set_ylim([min_v, max_v])

            min_v = min(np.min(self.measurements[:, -1]), np.min(self.predictions[:, -1]))
            max_v  = max(np.max(self.measurements[:, -1]), np.max(self.predictions[:, -1]))
            ax.set_xlim([min_v, max_v])

            fig.canvas.draw()
        axis_slider.on_changed(update_axis)

        # Hover
        circle_fit  = plt.Circle((-1, -1), .03, color='green', zorder=999)
        circle_pred = plt.Circle((-1, -1), .03, color='blue',  zorder=997)
        circle_roll = plt.Circle((-1, -1), .03, color='red',   zorder=998)
        ax.add_artist(circle_fit); ax.add_artist(circle_pred); ax.add_artist(circle_roll)

        def on_move(event):
            if event.inaxes:
                axis, rollout_num  = self.selected_axis, self.selected_rollout

                # Fit
                fit_i, fit_t = self.find_nearest(self.fits[:,-1], event.xdata)
                leg.texts[0].set_text(
                    f"Fit:    xy=({fit_t:.2f},{self.fits[fit_i, axis]:.2f}) v=({self.fits[fit_i, axis+3]:.2f})")
                circle_fit.center = fit_t, self.fits[fit_i, axis]

                # Pred
                pred_i, pred_t = self.find_nearest(self.predictions[:,-1], event.xdata)
                leg.texts[1].set_text(
                    f"Pred: xy=({pred_t:.2f},{self.predictions[pred_i, axis]:.2f}) v=({self.predictions[pred_i, axis+3]:.2f}) " +
                    f"dV=({self.fits[fit_i, axis+3] - self.predictions[pred_i, axis+3]:.2f})")
                circle_pred.center = pred_t, self.predictions[pred_i, axis]

                # Rollout
                roll_i, roll_t = self.find_nearest(self.rollouts[rollout_num][:, -1], event.xdata)
                roll_deriv = np.gradient(self.rollouts[rollout_num][:, axis], self.rollouts[rollout_num][:, -1])
                leg.texts[2].set_text(
                    f"Roll:  xy=({roll_t:.2f},{self.rollouts[rollout_num][roll_i, axis]:.2f}) v=({roll_deriv[roll_i]:.2f}) " +
                    f"dV=({self.fits[fit_i, axis+3] - roll_deriv[roll_i]:.2f})")
                circle_roll.center = roll_t, self.rollouts[rollout_num][roll_i, axis]

                fig.canvas.draw()
        binding_id = plt.connect('motion_notify_event', on_move)

        plt.show()


path = rospkg.RosPack().get_path('ball_calibration') + '/bags/vision_2022-07-30-16-12-02.bag'
EvalTrajectory(path)


