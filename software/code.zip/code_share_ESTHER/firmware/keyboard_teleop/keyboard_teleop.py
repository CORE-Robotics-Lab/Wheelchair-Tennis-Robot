import rospy
from std_msgs.msg import Float32
from getch import getch


def keyboard_control():
    rospy.init_node("computer_node")
    pub_command_vel_right = rospy.Publisher(
        "/command/velocities/right", Float32, queue_size=1
    )

    rate = rospy.Rate(200)  # 10hz

    # ---Initial Conditions---
    right_command = 0.0

    while not rospy.is_shutdown():

        key = getch()
        print(key)

        if key == "w" and right_command <= 30:
            right_command += 5

        if key == "p" and right_command <= 30:
            right_command += 1

        # - Slow Down-
        if key == "s" and right_command >= -25:
            right_command -= 5
        elif key == "s" and right_command < -25:
            right_command = -30

        if key == "l" and right_command >= -29:
            right_command -= 1
        elif key == "l" and right_command < -29:
            right_command = -30

        if key == "i":
            right_command = 5
        if key == "j":
            right_command = -5

        # - Hard Brake-
        if key == " ":
            right_command = 0

        if key == "Q":
            break

        pub_command_vel_right.publish(right_command)
        rate.sleep()


if __name__ == "__main__":
    try:
        keyboard_control()
    except rospy.ROSInterruptException:
        pass