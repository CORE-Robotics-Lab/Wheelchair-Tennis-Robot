import odrive
from odrive.enums import *
import time
import sys
import os


# Note: There seems to be a bug in the odrive.find_any() function that runs a
# background task that doesn't quit immediately upon ending of the script. This
# means that running the script quickly after recently stopping the script causes
# this script to hang indefinitely.


class ODrive:
    def __init__(self):
        # Find a connected ODrive (this will block until you connect one)
        self.odrive = odrive.find_any()

        # self.calibrate(axis=0)
        # self.calibrate(axis=1)
        # print("calibration complete")

        # print(self.odrive.axis0.controller.config.control_mode)
        # print(self.odrive.axis0.motor.is_calibrated)
        # print(self.odrive.axis0.encoder.is_ready)

        # self.enable_motor(axis=0)
        self.enable_motor(axis=1)
        # self.set_velocity(axis=0, velocity=0)
        self.set_velocity(axis=1, velocity=0)

        print("setup complete")

    def __del__(self):
        # Ensure velocities set to zero
        # self.set_velocity(axis=0, velocity=0)
        self.set_velocity(axis=1, velocity=0)
        print("cleaned up")

    def enable_motor(self, axis):
        # Check axis
        if axis == 0:
            self.odrive.axis0.requested_state = AXIS_STATE_CLOSED_LOOP_CONTROL
        if axis == 1:
            self.odrive.axis1.requested_state = AXIS_STATE_CLOSED_LOOP_CONTROL

    def idle(self, axis):
        # Check axis
        if axis == 0:
            self.odrive.axis0.requested_state = AXIS_STATE_IDLE
        if axis == 1:
            self.odrive.axis1.requested_state = AXIS_STATE_IDLE

    def calibrate(self, axis, savereboot=False):
        # Check axis
        if axis == 0:
            # Check if encoder is ready
            if not self.odrive.axis0.encoder.is_ready:
                self.odrive.axis0.requested_state = AXIS_STATE_ENCODER_INDEX_SEARCH

                # Wait for calibration sequence to finish
                while not self.odrive.axis0.encoder.is_ready:
                    # print(self.odrive.axis0.error)
                    # print(self.odrive.axis0.encoder.config.phase_offset)
                    # print(self.odrive.axis0.encoder.config.direction)
                    time.sleep(0.1)

            # Start calibration sequence
            self.odrive.axis0.requested_state = AXIS_STATE_FULL_CALIBRATION_SEQUENCE

            # Wait for calibration sequence to finish
            while self.odrive.axis0.current_state != AXIS_STATE_IDLE:
                time.sleep(0.1)

            # Save calibration sequence
            self.odrive.axis0.motor.config.pre_calibrated = True
        if axis == 1:
            # Check if encoder is ready
            if not self.odrive.axis1.encoder.is_ready:
                self.odrive.axis1.requested_state = AXIS_STATE_ENCODER_INDEX_SEARCH

                # Wait for calibration sequence to finish
                while not self.odrive.axis1.encoder.is_ready:
                    # print(self.odrive.axis0.error)
                    # print(self.odrive.axis0.encoder.config.phase_offset)
                    # print(self.odrive.axis0.encoder.config.direction)
                    time.sleep(0.1)

            # Start calibration sequence
            self.odrive.axis1.requested_state = AXIS_STATE_FULL_CALIBRATION_SEQUENCE

            # Wait for calibration sequence to finish
            while self.odrive.axis1.current_state != AXIS_STATE_IDLE:
                time.sleep(0.1)

            # Save calibration sequence
            self.odrive.axis1.motor.config.pre_calibrated = True

        if savereboot == True:
            # Save configuration and reboot
            self.odrive.save_configuration()

            # Wait for reboot to complete
            self.odrive = odrive.find_any()

    def set_velocity(self, axis, velocity):
        # Check axis
        if axis == 0:
            self.odrive.axis0.controller.input_vel = velocity
        if axis == 1:
            self.odrive.axis1.controller.input_vel = velocity


od = ODrive()


def main():
    while True:
        od.set_velocity(axis=1, velocity=2)
        time.sleep(5)
        od.set_velocity(axis=1, velocity=-2)
        time.sleep(5)


if __name__ == "__main__":
    try:
        main()
    finally:
        od.__del__()
        try:
            sys.exit(0)
        except SystemExit:
            os._exit(0)


def configuration():
    pass
    # self.odrive.config.enable_brake_resistor = True
    # self.odrive.config.brake_resistance = 2 # Ohms
    # self.odrive.config.dc_max_negative_current = -0.010 # Amps

    # # axis0
    # self.odrive.axis0.controller.config.vel_limit = 10 # turns/s
    # self.odrive.axis0.controller.config.control_mode = CONTROL_MODE_VELOCITY_CONTROL
    # self.odrive.axis0.motor.config.current_lim = 10 # amps
    # self.odrive.axis0.motor.config.calibration_current = 10 # amps
    # self.odrive.axis0.motor.config.pole_pairs = 7
    # self.odrive.axis0.motor.config.torque_constant = 8.27 / 150 # 8.27 / (motorKV)
    # self.odrive.axis0.motor.config.motor_type = MOTOR_TYPE_HIGH_CURRENT
    # self.odrive.axis0.motor.config.pre_calibrated = True
    # self.odrive.axis0.encoder.config.cpr = 8192
    # self.odrive.axis0.encoder.config.use_index = True
    # # self.odrive.axis0.controller.config.vel_ramp_rate = 0.5 # turns/s^2
    # # self.odrive.axis0.controller.config.input_mode = INPUT_MODE_VEL_RAMP

    # print("axis0 complete")

    # # axis1
    # self.odrive.axis1.controller.config.vel_limit = 10 # turns/s
    # self.odrive.axis1.controller.config.control_mode = CONTROL_MODE_VELOCITY_CONTROL
    # self.odrive.axis1.motor.config.current_lim = 10 # amps
    # self.odrive.axis1.motor.config.calibration_current = 10 # amps
    # self.odrive.axis1.motor.config.pole_pairs = 7
    # self.odrive.axis1.motor.config.torque_constant = 8.27 / 150 # 8.27 / (motorKV)
    # self.odrive.axis1.motor.config.motor_type = MOTOR_TYPE_HIGH_CURRENT
    # self.odrive.axis1.motor.config.pre_calibrated = True
    # self.odrive.axis1.encoder.config.cpr = 8192
    # self.odrive.axis1.encoder.config.use_index = True
    # # self.odrive.axis1.controller.config.vel_ramp_rate = 0.5 # turns/s^2
    # # self.odrive.axis1.controller.config.input_mode = INPUT_MODE_VEL_RAMP

    # print("axis1 complete")

    # try:
    #     # Save configuration and reboot
    #     self.odrive.save_configuration()
    # except:
    #     time.sleep(5)
    #     # Wait for reboot to complete
    #     self.odrive = odrive.find_any()
    # print("reboot complete")
