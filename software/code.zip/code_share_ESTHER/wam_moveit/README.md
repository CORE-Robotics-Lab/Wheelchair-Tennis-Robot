This package is inspired by [jhu-lcsr's barrett_moveit](https://github.com/jhu-lcsr/barrett_moveit). Some config's have edited and extra files have been deleted to reduce cluster.
