Package for creating Gazebo Tennis World for WAM arm

Gazebo doesn't really work currently