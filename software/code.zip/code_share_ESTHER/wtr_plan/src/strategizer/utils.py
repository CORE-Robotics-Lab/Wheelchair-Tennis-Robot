def debug_msg(src, msg):
    return '[{}] {}'.format(src, msg)
