# Wheelchair-Tennis-Robot

The Central Repo for the Wheelchair Tennis Robot Project

<p align="center">
    <img src="documents/photos/robot_fall21.jpg" alt="Robot" width="200" />
</p>

Overall Pipeline Diagram:

<p align="center">
    <img src="documents/photos/wtr_arch.png" alt="Diagram" width="1000" />
</p>

## Outline

Goal is to develop a motorized wheelchair with a racket-swinging robotic arm that can play tennis.

[Summer 2021 Project Slides](https://docs.google.com/presentation/d/1DEO_nW_IQxAMBXUgFWKJR60ujcmVogU_cVYDlZwmgcY/edit?usp=sharing)


Please refer to other guides!